<?php
  require('header.php');
?>
<?php
  $pictures = array('green.png','blue.png','red.png','cat.jpg','money.jpg');

  shuffle($pictures);
?>
<?php
  require('adspace.php');
?>
    <h1>Welcome</h1>
    <figure>
    <a href="donate.html"><img src="<?php echo $pictures[0]; ?>" alt="Random Image"/></a>
        <figcaption>Click to Donate</figcaption>
    </figure>
<?php
  require('footer.php');
?>