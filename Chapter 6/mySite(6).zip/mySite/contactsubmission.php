<?php

$name = trim($_POST['name']);
$email = trim($_POST['email']);
$message = trim($_POST['feedback']);

$toaddress = $_POST['department'] . "@example.com";

$subject = $_POST['department'] . "from Contact Us";

$mailcontent = "Customer name: ".str_replace("\r\n", "", $name)."\n".
               "Customer email: ".str_replace("\r\n", "",$email)."\n".
               "Customer comments:\n".str_replace("\r\n", "",$feedback)."\n";

$fromaddress = "From: " . $email;

mail($toaddress, $subject, $mailcontent, $fromaddress);

?>
<!DOCTYPE html>
<html>
  <head>
    <title>Email Submitted</title>
    <link href="format.css" rel="stylesheet" />
  </head>
  <body>

    <h1>Email Submitted</h1>
    <p>Thank you for contacting us</p>
  </body>
</html>