<?php
require_once("file_exceptions.php");

$donorName = $_POST['login'];
$donate = $_POST['donate'];
$date = date('Y-m-d'); 
$displayDate = date('H:i, jS F Y');
$Rewards = "None";

if (!is_numeric($donate)) {
    $donate = 0;
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Donation Submission</title>
    <link href="format.css" rel="stylesheet" />
</head>
<body>
    <h1>Donation</h1>
    <h3><a href="homepage.php">Return Home</a></h3>
    <?php
    echo "<p>Donation Submitted on $displayDate</p>";
    echo '<p>Thank you "' . htmlspecialchars($donorName) . '" for Donating: </p>';
    echo '<h1 id="donate">$' . htmlspecialchars($donate) . '</h1>';

    if ($donate >= 5) {
        $Rewards = "Pin";
        echo "<p>Limited Edition Pin: 45DG4-EHC48-PO34L</p>";
    }
    if ($donate > 10) {
        $Rewards = "Pin + Code";
        echo "<p>Steam Code: 5UI8F-23WBJ-KU87S</p>";
    }
    if ($donate > 20) {
        $Rewards = "Pin + Code + Beta";
        echo "<p>Beta Test: 43YH5-88EW4-2JK67</p>";
    }

    $db = new mysqli('localhost', 'admin', 'Gamers123', 'donations');

    if ($db->connect_error) {
        echo "<p>Error: Could not connect to database.<br/> Please try again later.</p>";
        exit;
    }

    $stmt_lookup = $db->prepare("SELECT LoginID FROM login WHERE Name = ?");
    $stmt_lookup->bind_param('s', $donorName);
    $stmt_lookup->execute();
    $stmt_lookup->bind_result($LoginID);
    $stmt_lookup->fetch();
    $stmt_lookup->close();

    if (!$LoginID) {
        echo "<p>Error: Could not find LoginID for donor name '$donorName'.</p>";
        $db->close();
        exit;
    }

    $query = "INSERT INTO donation (LoginID, Donation, Date, Rewards) VALUES (?, ?, ?, ?)";
    $stmt = $db->prepare($query);
    $stmt->bind_param('idss', $LoginID, $donate, $date, $Rewards);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo "<p>Donation successfully entered into the database.</p>";
    } else {
        echo "<p>An error has occurred.<br/>Donation unsuccessful.</p>";
    }

    $stmt->close();
    $db->close();
    ?>
</body>
</html>
