<?php require('header.php'); ?>

<form action="processdonate.php" method="post">
    <figure>
        <table>
            <tr id="rowTitles">
                <td><strong>Donation Size</strong></td>
                <td><strong>Bonus Gift</strong></td> 
            </tr>
            <tr>
                <td>$5.00 to $10.00</td>
                <td>Limited Edition Pin</td>
            </tr>
            <tr>
                <td>$10.01 to $20.00</td>
                <td>Pin + Steam Game Code</td>
            </tr>
            <tr>
                <td>$20.01 or MORE</td>
                <td>Pin + Game + Beta Test</td>
            </tr>
        </table>
        <figcaption><br />*Codes will be given for each bonus gift after donation is submitted.</figcaption>

        <p>
            <label for="login"><strong>Your Name (as registered):</strong></label><br>
            <input type="text" name="login" id="login" required>
        </p>

        <p>
            <label for="donate"><strong>Donation Amount:</strong></label><br>
            $<input type="number" name="donate" id="donate" step="0.01" min="0" required>
        </p>

        <input type="submit" value="Submit Donation">
    </figure>
</form>

<h3><a href="search_donations.php">View Your Donations</a></h3>

<?php require('footer.php'); ?>
