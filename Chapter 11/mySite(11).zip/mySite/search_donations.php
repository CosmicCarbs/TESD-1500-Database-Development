<?php require('header.php'); ?>

<h3>Search Donations</h3>

<form action="your_donations.php" method="post">
  <p><strong>Enter your LoginID:</strong><br />
    <input name="LoginID" type="number" size="11" required>
  </p>
  <p><input type="submit" name="submit" value="Search"></p>
</form>

<?php require('footer.php'); ?>
