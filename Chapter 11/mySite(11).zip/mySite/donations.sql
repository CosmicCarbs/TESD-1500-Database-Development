-- phpMyAdmin SQL Dump
-- version 5.1.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 11, 2025 at 07:42 PM
-- Server version: 5.7.24
-- PHP Version: 8.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

CREATE DATABASE donations;

-- --------------------------------------------------------

CREATE TABLE `login` (
  `LoginID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `City` varchar(50) NOT NULL,
  PRIMARY KEY (`LoginID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

CREATE TABLE `donation` (
  `DonationID` int(11) NOT NULL AUTO_INCREMENT,
  `LoginID` int(11) NOT NULL,
  `Donation` decimal(10,2) NOT NULL,
  `Date` date NOT NULL,
  `Rewards` varchar(100) NOT NULL,
  PRIMARY KEY (`DonationID`),
  KEY `LoginID` (`LoginID`),
  CONSTRAINT `LoginID` FOREIGN KEY (`LoginID`) REFERENCES `login` (`LoginID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

INSERT INTO `login` (LoginID, Name, Address, City) VALUES
(1, 'Dan Smith', '375 North Lagoon Drive', 'Provo'),
(2, 'Donkey Teeth', '84 West Duke Street', 'Krabby'),
(3, 'Quatro Quatro', '75932 Highland Avenue', 'Crazytown'),
(4, 'Davoin Shower-Handel', '25 Oak Street', 'Airport West'),
(5, "L'Carpetron Dookmarriot", '1/47 Haines Avenue', 'Box Hill'),
(6, 'T.J. Juckson', '357 North Road', 'Yarraville');

INSERT INTO `donation` (DonationID, LoginID, Donation, Date, Rewards) VALUES
(1, 1, 15.00, '2023-12-15', 'Pin + Game'),
(2, 2, 5.00, '2024-02-22', 'Pin'),
(3, 4, 11.00, '2024-03-04', 'Pin + Game'),
(4, 1, 30.00, '2024-07-11', 'Pin + Game + Beta'),
(5, 3, 1.00, '2025-01-01', '');

COMMIT;
