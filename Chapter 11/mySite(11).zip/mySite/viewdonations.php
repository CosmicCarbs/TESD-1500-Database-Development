<?php
  $document_root = $_SERVER['DOCUMENT_ROOT'];
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Submitted Donations</title>
  </head>
  <body>
    <h1>Donations Submitted</h1>

    <?php
      $file_path = $document_root . "/../mySite/donations.txt";
      echo "File path: " . $file_path;  

      $fp = fopen($file_path, 'rb');
      flock($fp, LOCK_SH);  

      if (!$fp) {
        echo "<h2>Error: Could not open the file.</h2>";
        exit;
      }

      $donations = file($file_path, FILE_IGNORE_NEW_LINES);  
      if (count($donations) > 0) {
          foreach ($donations as $donation) {
              echo htmlspecialchars($donation) . "<br />";
          }
      } else {
          echo "<h2>No Donations.</h2>";
      }

      flock($fp, LOCK_UN);  
      fclose($fp);
    ?>

    <h3><a href="homepage.php">Return Home</a></h3>
  </body>
</html>
