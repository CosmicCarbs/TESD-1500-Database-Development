<?php require('header.php'); ?>

<h1>Your Donations</h1>
<h3><a href="homepage.php" style="font-size: 16px; color: #007BFF;">Return Home</a></h3>

<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['LoginID'])) {
    $LoginID = trim($_POST['LoginID']);

    if (!ctype_digit($LoginID)) {
        echo '<p>You must provide a valid integer LoginID to search.</p>';
        exit;
    }

} else {
    echo '<p>You must provide a valid LoginID to search.</p>';
    exit;
}

$db = new mysqli('localhost', 'admin', 'Gamers123', 'donations');

if ($db->connect_error) {
    echo '<p>Error: Could not connect to database.<br/> Please try again later.</p>';
    exit;
}


$query = "SELECT DonationID, Donation, Date, Rewards FROM donation WHERE LoginID = ?";
$stmt = $db->prepare($query);

if ($stmt === false) {
    echo "<p>Prepared statement failed: " . $db->error . "</p>";
    exit;
}

$stmt->bind_param('i', $LoginID);

if (!$stmt->execute()) {
    echo "<p>Execution failed: " . $stmt->error . "</p>";
    exit;
}

$stmt->store_result();
echo "<p><strong>Rows found:</strong> " . $stmt->num_rows . "</p>"; 

if ($stmt->num_rows > 0) {
    $stmt->bind_result($DonationID, $Donation, $Date, $Rewards);

    while ($stmt->fetch()) {
        $formattedDate = $Date ? date('F j, Y', strtotime($Date)) : 'Unknown Date';

        echo "<div style='border:1px solid #ccc; padding:10px; margin-bottom:10px;'>";
        echo "<strong>DonationID:</strong> $DonationID<br />";
        echo "<strong>Donation Amount:</strong> \$$Donation<br />";
        echo "<strong>Date:</strong> $formattedDate<br />";
        echo "<strong>Rewards:</strong> $Rewards";
        echo "</div>";
    }
} else {
    echo "<p>No donations found for LoginID $LoginID.</p>";
}

$stmt->free_result();
$db->close();
?>

<?php require('footer.php'); ?>
