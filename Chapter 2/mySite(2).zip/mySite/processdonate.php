<?php
$name = $_POST['name'];
$donate = $_POST['donate'];
$date = date('H:i, jS F Y');
$document_root = $_SERVER['DOCUMENT_ROOT'];
if (!is_numeric($donate)) {
    $donate = 0;
}
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Donation Submission</title>
    <link href="format.css" rel="stylesheet" />
  </head>
  <body>
    <h1>Donation</h1>
    <?php
    echo "<p>Donation Submitted on $date</p>";
    echo '<p>Thank you "'.$name. '" for Donating: </p>';
    echo '<h1 id="donate">$' . htmlspecialchars($donate) . '</h1>';

    if($donate >= 5){
        echo "<p> Limited Edition Pin: 45DG4-EHC48-PO34L </p>";
    }
    if($donate > 10){
        echo "<p> Steam Code: 5UI8F-23WBJ-KU87S </p>";
    }
    if($donate > 20){
        echo "<p> Beta Test: 43YH5-88EW4-2JK67 </p>";
    }

    $outputstring = $date."\t|\t".$name."\t|\t$".$donate."\n";

    $fp = fopen("$document_root/../donations.txt", 'a');

       if (!$fp) {
         echo "<h2>Error, please try agian later</h2>";
         exit;
       }

       flock($fp, LOCK_EX);
       fwrite($fp, $outputstring, strlen($outputstring));
       flock($fp, LOCK_UN);
       fclose($fp);

       echo "<h2>Donation Recevied.</h2>";
    ?>
  </body>
</html>