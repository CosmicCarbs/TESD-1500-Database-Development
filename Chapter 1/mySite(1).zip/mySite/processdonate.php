<?php
$donate = $_POST['donate'];
if (!is_numeric($donate)) {
    $donate = 0;
}
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Donation Submission</title>
    <link href="format.css" rel="stylesheet" />
  </head>
  <body>
    <h1>Donation Submitted</h1>
    <?php
    echo "<p>Donation Submitted on ";
    echo date('H:i, jS F Y');
    echo "</p>";

    echo '<p>Thank you for Donating: </p>';
    echo '<h1 id="donate">$' . htmlspecialchars($donate) . '</h1>';

    if($donate >= 5){
        echo "<p> Limited Edition Pin: 45DG4-EHC48-PO34L </p>";
    }
    if($donate > 10){
        echo "<p> Steam Code: 5UI8F-23WBJ-KU87S </p>";
    }
    if($donate > 20){
        echo "<p> Beta Test: 43YH5-88EW4-2JK67 </p>";
    }
    ?>
  </body>
</html>