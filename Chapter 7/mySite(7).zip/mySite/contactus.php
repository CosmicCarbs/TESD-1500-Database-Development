<?php
  require('header.php');
?>
    <h1>Contact us</h1>

    <form action="contactsubmission.php" method="post">

    <p><strong>Topic:</strong><br/>
    <select name="department">
        <option value = "feedback">Feedback</option>
        <option value = "questions">Q&A Questions</option>
        <option value = "delivery">Delivery Issues</option>
        <option value = "ideas">Ideas</option>
        <option value = "other">Other</option>
        </select>

    <p><strong>Your name:</strong><br/>
    <input type="text" name="name" size="40" /></p>
     
    <p><strong>Your email address:</strong><br/>
    <input type="text" name="email" size="40" /></p>
     
    <p><strong>Your message:</strong><br/>
    <textarea name="message" rows="8" cols="40">
    </textarea></p>
     
    <p><input type="submit" value="Send" /></p>  
    </form>
    
    <?php
    require('footer.php');
  ?>
