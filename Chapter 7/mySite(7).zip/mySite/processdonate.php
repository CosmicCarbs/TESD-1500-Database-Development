<?php
require_once("file_exceptions.php");
$name = $_POST['name'];
$donate = $_POST['donate'];
$date = date('H:i, jS F Y');
$document_root = $_SERVER['DOCUMENT_ROOT'];

if (!is_numeric($donate)) {
    $donate = 0;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Donation Submission</title>
    <link href="format.css" rel="stylesheet" />
</head>
<body>
    <h1>Donation</h1>
    <?php
    echo "<p>Donation Submitted on $date</p>";
    echo '<p>Thank you "' . htmlspecialchars($name) . '" for Donating: </p>';
    echo '<h1 id="donate">$' . htmlspecialchars($donate) . '</h1>';

    if ($donate >= 5) {
        echo "<p>Limited Edition Pin: 45DG4-EHC48-PO34L </p>";
    }
    if ($donate > 10) {
        echo "<p>Steam Code: 5UI8F-23WBJ-KU87S </p>";
    }
    if ($donate > 20) {
        echo "<p>Beta Test: 43YH5-88EW4-2JK67 </p>";
    }

    $outputstring = $date . "\t|\t" . htmlspecialchars($name) . "\t|\t$" . $donate . "\n";

    try {
        if (!($fp = fopen("$document_root/../mySite/donations.txt", 'a'))) {
            throw new fileOpenException();
        }

        if (!flock($fp, LOCK_EX)) {
            throw new fileLockException();
        }

        if (!fwrite($fp, $outputstring, strlen($outputstring))) {
            throw new fileWriteException();
        }

        flock($fp, LOCK_UN);
        fclose($fp);

        echo "<h2>Donation Received.</h2>";
    } catch (fileOpenException $foe) {
        echo "<p><strong>Error: Donations file could not be opened.<br/>Please contact our IT at (123)456-7890 for help.</strong></p>";
    } catch (Exception $e) {
        echo "<p><strong>Apologies, your donation could not be processed at this time.<br/>Please try again later.</strong></p>";
    }
    ?>
</body>
</html>
