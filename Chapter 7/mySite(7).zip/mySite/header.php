<!DOCTYPE html>
<html>
<head>
  <title>header</title>
  <meta charset="UTF-8">
  <link href="format.css" rel="stylesheet">
</head>
<body>

  <header>    
    <h1>Gaming Studios</h1>
  </header>

  <nav>
    <div class="menuitem">
      <a href="homepage.php">
      <span class="menutext">Home</span>
      </a>
    </div>

    <div class="menuitem">
      <a href="donate.php">
      <span class="menutext">Donate</span>
      </a>
    </div>

    <div class="menuitem">
      <a href="contactus.php">
      <span class="menutext">Contact Us</span>
      </a>
    </div>
  </nav>