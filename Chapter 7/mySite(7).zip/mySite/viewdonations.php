<?php
  $document_root = $_SERVER['DOCUMENT_ROOT'];
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Submitted Donations</title>
  </head>
  <body>
    <h1>Donations Submitted</h1>
    <?php
      $fp = fopen("$document_root/../mySite/donations.txt", 'rb');
      flock($fp, LOCK_SH); 

      if (!$fp) {
        echo "<h2>No Donations.</h2>";
        exit;
      }

      while (!feof($fp)) {
         $donation= fgets($fp);
         echo htmlspecialchars($donation)."<br />";
      }

      flock($fp, LOCK_UN); 
      fclose($fp); 

    ?>
  </body>
</html>